# Stratum Protocol

## Motivation

Afer reviewing the new Blockchain [Defensive Patent License - BPDL](https://www.asicboost.com/single-post/2018/03/01/offering-announcement-blockchain-defensive-patent-license/), we would see beneficial for the community to have a central place with stratum protocol specification. At the same time, we have have been working on a proposal for [stratum protocol extensions](/stratum-extensions).

## Basic Stratum specification

For the time being, the basic/original Stratum Specification is still available through [Slush Pool website](https://slushpool.com/help/manual/stratum-protocol). The plan is to migrate also this information to this site.

**Slush Pool Team**
